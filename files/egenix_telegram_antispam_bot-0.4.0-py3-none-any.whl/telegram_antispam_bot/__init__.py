#!/usr/bin/env python3

""" eGenix Antispam Bot for Telegram Package

    Written by Marc-Andre Lemburg in 2022.
    Copyright (c) 2022, eGenix.com Software GmbH; mailto:info@egenix.com
    License: MIT
"""
### Globals

# Package version
#__version__ = '0.4.0.dev3'
__version__ = '0.4.0'
